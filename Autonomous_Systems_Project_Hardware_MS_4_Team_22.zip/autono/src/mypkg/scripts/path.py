#!usr/bin/env
import rospy
from std_msgs.msg import String
from std_msgs.msg import Float64
import time
import math
time.sleep(10)
rospy.init_node('path')

pub1=rospy.Publisher('longdes',Float64,queue_size=10)
pub2=rospy.Publisher('latedes',Float64,queue_size=10)
rate=rospy.Rate(10)
v=0.5
l=0
dax=0
ora=0
spa=0
def callback(data):
    actual=data.data.split(" ")
    global spa,dax,ora,day
    spa=float(actual[0])
    ora=float(actual[1])
    dax=spa*math.cos(ora)*tau
def getdata():
 sub=rospy.Subscriber('actualdata',String,callback)
print(dax)
print("once")

tau=0.01
st=time.time()
while 1 and not rospy.is_shutdown():
    st=time.time()
    print("running path")
    if(dax>3):
        v=0.5
        l=-0.5
    if(dax>6.5):
        v=1
        l=0.5
    if(dax>10):
        v=0
        l=0
      
    getdata()

    pub1.publish(v)
    pub2.publish(l)
    end=time.time()
    # tau=end-tau
    rate.sleep()

    print(v)
    print(l)
    print(spa)
    print(ora)
    print(dax)
    print(tau)