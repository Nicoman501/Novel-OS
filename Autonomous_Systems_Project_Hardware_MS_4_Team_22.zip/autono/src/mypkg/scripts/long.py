#!usr/bin/env
import rospy
from std_msgs.msg import String
from std_msgs.msg import Float64
import time
import math
time.sleep(10)

rospy.init_node('long_node')

pub=rospy.Publisher('longcont',Float64,queue_size=10)
rate=rospy.Rate(10)

vdes=0
spa=0

def rec(data):
    global vdes
    vdes=data.data

def callback(data):
    actual=data.data.split(" ")
    global spa,ora
    spa=float(actual[0])
    ora=float(actual[1])

def getdata():
 sub2=rospy.Subscriber('actualdata',String,callback)
 sub1=rospy.Subscriber('longdes',Float64,rec)

def spc(vdes,spa):
    u=2*(vdes-spa)
    if(u>2):
        u=0
    vout=spa+tau*u
    return vout

tau=0.01
vout=0
st=time.time()
print("once")
while 1 and not rospy.is_shutdown():
    print("running long")
    st=time.time()

    getdata()
    
    vout=spc(vdes,spa)

    pub.publish(vout)
    rate.sleep()
    
    end=time.time()
    # tau=end-st
    print(spa)
    print(vout)