#!usr/bin/env
import rospy
from std_msgs.msg import *
import time
import math
import serial

time.sleep(10)
rospy.init_node('temp')

pub=rospy.Publisher('actualdata',String,queue_size=10)
rate=rospy.Rate(10)
ser=serial.Serial('/dev/ttUSB0',9600,timeout=1)
ser.reset_input_buffer()
spo=0
ano=0

def callback1(data):
    global spo
    spo=data.data

def callback2(data):
    global ano
    ano=data.data
def getdata():
    sub1=rospy.Subscriber('longcont',Float64,callback1)
    sub2=rospy.Subscriber('latecont',Float64,callback2)

def datain():
    return str(spo)+" "+str(ano)
tau=0.01
st=time.time()
print("once")

while 1 and not rospy.is_shutdown():  
    print("RUNING temp")
    ser.reset_input_buffer()
    while ser.in_waiting<=0:
        time.sleep(0.01)
    datain=ser.readline().decode('utf-8').rstrip()
    st=time.time()
    pub.publish(datain)
    rate.sleep()

    getdata()
    msg=datain()
    time.sleep(0.6)
    ser.write(msg.encode('utf-8'))
    end=time.time()

    tau=end-st
    print(msg)