#!usr/bin/env
import rospy
from std_msgs.msg import String
from std_msgs.msg import Float64
import time
import math
time.sleep(10)
rospy.init_node('late_node')
pub=rospy.Publisher('latecont',Float64,queue_size=10)
rate=rospy.Rate(10)
delta=0
ora=0
spa=0
ty=0
day=0
spa=0.5
def rec(data):
    global ty
    ty=data.data

def callback(data):
    actual=data.data.split(" ")
    global spa,dax,ora
    spa=float(actual[0])
    ora=float(actual[1])

def getdata():
 sub2=rospy.Subscriber('actualdata',String,callback)
 sub1=rospy.Subscriber('latedes',Float64,rec)

def rotare():
   global day
   delta=ty-day
   day=day+spa*tau*math.sin(delta)
   if abs(delta)<0.05:
      delta=0
   return delta

delta=0
tau=0.01
st=time.time()
print("once")

while 1 and not rospy.is_shutdown():
    print("runing late")
    st=time.time()

    getdata()
    
    delta=rotare()
    
    pub.publish(delta)
    rate.sleep()
    
    end=time.time()
    # tau=end-st
    print(delta)
    print(day)
    print(ty)