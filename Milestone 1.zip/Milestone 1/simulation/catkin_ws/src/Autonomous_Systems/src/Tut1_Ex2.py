#!/usr/bin/env python3

import rospy #get the libraries of rospy

rospy.init_node('Tut1_Ex1') #method used to intitiate a node
i=0
while i<10:
        print('Hello World') #to print hello world on terminal...
        i=i+1

